/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import Dominio.formas.formaCuadrado;


/**
 *  El nodo seran los puntos en el tablero
 * @author Hiram
 */
public class Nodo extends formaCuadrado{
    public Nodo(int width, int height, int x, int y) {
        super(width,height,x,y);
    }
}
