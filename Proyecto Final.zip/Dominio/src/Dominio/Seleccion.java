/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;


import java.util.*;

/**
 *
 * @author Hiram
 */
public class Seleccion {
    private List<String> colorJugadores;
    
    public Seleccion(String colorLinea2,String colorLinea3,String colorLinea4){
        colorJugadores = new ArrayList<>();
        colorJugadores.add(colorLinea2);
        colorJugadores.add(colorLinea3);
        colorJugadores.add(colorLinea4);
    }
    public List<String> getColores(){
        return colorJugadores;
    }
    public void setColores(List<String> colores){
        this.colorJugadores = colores;
    }
}
