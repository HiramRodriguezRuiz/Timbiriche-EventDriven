/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Hiram
 */
public class ordenJugadores {
    private Jugador primerTurno;
    private int siguiente;
    private List<Jugador> jugadores;
    
    public ordenJugadores(Jugador lider){
        this.jugadores = new ArrayList<>();
        this.primerTurno = lider;
        this.siguiente = 0;
    }
    public ordenJugadores(List<Jugador> jugadores){
        this.jugadores = jugadores;
        if(this.jugadores.get(0) != null){
            this.primerTurno = this.jugadores.get(0);
            this.siguiente = 0;
        }
    }
    public Jugador getPrimero(){
        return this.primerTurno;
    }
    public void setPrimero(Jugador primero){
        this.primerTurno = primero;
    }
    public int getSiguiente(){
        int siguienteTemporal = this.siguiente;
        if(siguiente == this.jugadores.size()){
            return this.siguiente = 0;
        }
        return siguienteTemporal;
    }
        public List<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(List<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
    public void turnos(){
        Collections.shuffle(this.jugadores);
    }

    @Override
    public String toString() {
        return "jugadorSiguiente{" + "primerTurno=" + primerTurno + ", siguiente=" + siguiente + ", jugadores=" + jugadores + '}';
    }
    
}
