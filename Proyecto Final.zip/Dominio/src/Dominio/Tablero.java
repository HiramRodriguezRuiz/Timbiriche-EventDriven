/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hiram
 */
public class Tablero {

    private int tamaño;
    private List<Cuadro> cuadritos;
    private List<Linea> lineasHorizontales;
    private List<Linea> lineasVerticales;
    private List<Nodo> nodos;

    public Tablero() {
        lineasHorizontales = new ArrayList<>();
        lineasVerticales = new ArrayList<>();
        cuadritos = new ArrayList<>();
        nodos = new ArrayList<>();
    }

    public Tablero(int tamaño) {
        lineasHorizontales = new ArrayList<>();
        lineasVerticales = new ArrayList<>();
        cuadritos = new ArrayList<>();
        switch (tamaño) {
            case 2:
                this.tamaño = 10;
                break;
            case 3:
                this.tamaño = 20;
                break;
            case 4:
                this.tamaño = 40;
                break;
        }
    }

    /**
     * Método encargado de asignar un jugador 
     * despues crea instancias de lineas
     * y las guarda en una estructura
     */
    public void generarInstanciaFormaJuego() {
        for (int i = 0; i < ((tamaño - 1) * tamaño); i++) {
            lineasHorizontales.add(new Linea(Posicion.HORIZONTAL, null, i));
            lineasVerticales.add(new Linea(Posicion.VERTICAL, null, i));
        }

        //Crea instancias de Cuadro utilizando las instancias de lineas creadas
        for (int i = 0; i < tamaño - 1; i++) {
            int indicador = i;
            for (int j = i * (tamaño - 1); j < i * (tamaño - 1) + (tamaño - 1); j++) {
                cuadritos.add(new Cuadro(lineasHorizontales.get(j),
                        lineasHorizontales.get(j + (tamaño - 1)),
                        lineasVerticales.get(indicador),
                        lineasVerticales.get(indicador + (tamaño - 1)), null, j));

                indicador += (tamaño - 1);
            }
        }
    }

    public Tablero(int tamaño, List<Linea> lineasHorizontales, List<Linea> lineasVerticales, List<Cuadro> cuadros, List<Nodo> nodos) {
        this.tamaño = tamaño;
        this.lineasHorizontales = lineasHorizontales;
        this.lineasVerticales = lineasVerticales;
        this.cuadritos = cuadros;
        this.nodos = nodos;
    }

    public int getDimension() {
        return tamaño;
    }

    public void setDimension(int dimension) {
        this.tamaño = dimension;
    }

    public List<Linea> getLineasHorizontales() {
        return lineasHorizontales;
    }

    public void setLineasHorizontales(List<Linea> lineasHorizontales) {
        this.lineasHorizontales = lineasHorizontales;
    }

    public List<Linea> getLineasVerticales() {
        return lineasVerticales;
    }

    public void setLineasVerticales(List<Linea> lineasVerticales) {
        this.lineasVerticales = lineasVerticales;
    }

    public List<Cuadro> getCuadros() {
        return cuadritos;
    }

    public void setCuadros(List<Cuadro> cuadros) {
        this.cuadritos = cuadros;
    }

    public List<Nodo> getPuntos() {
        return nodos;
    }

    public void setPuntos(List<Nodo> puntos) {
        this.nodos = puntos;
    }
}
