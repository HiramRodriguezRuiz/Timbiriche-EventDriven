/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Hiram
 */
public class Partida {
    public ordenJugadores jugadores;
    public Tablero tablero;
    public int estado;
    //Jugadores que componen la partida o la sala
    public int nJugadores;
    
    public Partida(){
        
    }
    /**
     * M. Constructor de la Partida
     * @param jugadores
     * @param tablero
     * @param nJugadores 
     */
    public Partida(ordenJugadores jugadores,Tablero tablero,int nJugadores){
        this.tablero = tablero;
        this.jugadores = jugadores;
        this.nJugadores = nJugadores;
    }
    public Tablero getTablero() {
        return tablero;
    }

    public void setTablero(Tablero tablero) {
        this.tablero = tablero;
    }
    public ordenJugadores getOJugadores(){
        return jugadores;
    }
    public void setOJugadores(ordenJugadores jugadores){
        this.jugadores = jugadores;
    }
    public int getTamañoPartida() {
        return nJugadores;
    }
    public void setTamañoPartida(int tamaño) {
        this.nJugadores = tamaño;
    }
    public void agregarJugador(Jugador jugador) {
        if (this.jugadores.getJugadores().size() < this.nJugadores) {
            this.jugadores.getJugadores().add(jugador);
        }
    }

    public void eliminarJugador(Jugador jugador) {
        this.jugadores.getJugadores().remove(jugador);
    }
}
