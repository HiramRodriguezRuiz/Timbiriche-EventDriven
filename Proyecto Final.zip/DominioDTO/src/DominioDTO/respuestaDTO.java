/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DominioDTO;

import java.io.Serializable;

/**
 *
 * @author Hiram, Adrian
 */
public class respuestaDTO implements Serializable{
    private MovimientoDTO movimiento;
    private ordenJugadoresDTO orden;

    public respuestaDTO(MovimientoDTO movimiento, ordenJugadoresDTO marcador) {
        this.movimiento = movimiento;
        this.orden = marcador;
    }

    public MovimientoDTO getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(MovimientoDTO movimiento) {
        this.movimiento = movimiento;
    }

    public ordenJugadoresDTO getOrden() {
        return orden;
    }

    public void setOrden(ordenJugadoresDTO marcador) {
        this.orden = marcador;
    }
}
