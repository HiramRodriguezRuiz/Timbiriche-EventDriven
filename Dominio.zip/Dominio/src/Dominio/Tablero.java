/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;


/**
 *
 * @author Equipo 4
 */
public class Tablero {

    private int tamaño;
    private Cuadro cuadritos[];

    /**
     * Método de acceso para obtener el tamaño del tablero
     * 
     * @return tamaño
     */
    public int getTamaño() {
        return tamaño;
    }
    /**
     * Método de acceso para asignarle un tamaño a tablero
     * 
     * @param tamaño que se le asignará a tablero
     */
    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
    /**
     * Método de acceso para obtener el arreglo de Cuadro
     * 
     * @return un arreglo de Cuadro
     */
    public Cuadro[] getCuadritos() {
        return cuadritos;
    }
    /**
     * Método de acceso que asigna valor al arreglo de tipo Cuadro, donde se 
     * almacenan los datos de cada Cuadro acompletado o no
     * 
     * @param cuadritos el valor que se le asignará al arreglo
     */
    public void setCuadritos(Cuadro[] cuadritos) {
        this.cuadritos = cuadritos;
    }
    
    
    
}